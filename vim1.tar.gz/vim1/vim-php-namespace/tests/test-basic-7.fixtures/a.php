<?php

namespace Foo;

interface Bar {
}

