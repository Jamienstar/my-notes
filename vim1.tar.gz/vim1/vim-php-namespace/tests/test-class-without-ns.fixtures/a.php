<?php

class Foo {
}

