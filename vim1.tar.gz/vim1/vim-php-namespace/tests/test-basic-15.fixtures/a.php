<?php

namespace Foo;

class Bar {
}

