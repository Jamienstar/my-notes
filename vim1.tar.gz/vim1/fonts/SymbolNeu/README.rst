Symbol Neu Powerline
====================

:Font creator: Steve Matteson
:Version: 1.0
:Source: http://gsdview.appspot.com/chromeos-localmirror/distfiles/
:License:  Apache License, Version 2.0
:Patched by: `Loic Pefferkorn  <https://github.com/lpefferkorn>`_

Symbol Neu is a metrically compatible font to Symbol.

Symbol Neu Powerline is derived from Symbol Neu for Powerline users.
The Powerline symbols is being made by Kim Silkebækken. The patch work
is being undertaken by Loic Pefferkorn.
