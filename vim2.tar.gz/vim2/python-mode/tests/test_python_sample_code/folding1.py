"""One liner.

Multi line.

Docstring.

"""

import math


def top_function(a, b, c):
    """One liner docstring."""
    print(a)
    print(b)
    print(c)


if __name__ == '__main__':
    top_function(math.e, 1, 'si')
