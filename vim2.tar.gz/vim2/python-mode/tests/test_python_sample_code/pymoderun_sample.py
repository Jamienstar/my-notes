# Output more than 5 lines to stdout.
a = 10
for z in range(a):
    print(z)
