General API
------------

.. automodule:: astroid

