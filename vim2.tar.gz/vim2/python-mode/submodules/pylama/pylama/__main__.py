"""Support the module execution."""

from .main import shell

if __name__ == '__main__':
    shell()
